# CSCI 104 Lab Skeleton Code

Please clone this repository, copy the lab folders into a different directory, and work at that directory. Do not work in the directory where you cloned the lab repository.
